<?php
	$DIRNAME=$_GET["dirname"];
	$file=fopen("Dirs.txt","w") or die("Error:Not Read Config Files");
	fwrite($file,"$DIRNAME");
	fclose($file);
	echo("<script>window.open('ConfigSure.html');</script>");
?>