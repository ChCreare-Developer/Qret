<?php
	echo <<<EOF
		<style>
		body{
			background-image:url("Lemon.jpg");
			color:white;
		}
		</style>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
	EOF;
	echo "<title>马上就好</title>";
	echo "<center><h1>欢迎使用Qret页面自定义工具！</h1></center>";
	echo "<center><p>Version:Beta2</p></center>";
	echo "<center><p>当你看到这个界面时，你的Qret和服务器的PHP已经准备就绪</p></center>";
	echo "<center><p>请<a href=config.html>点这里</a>继续</p></center>";
?>