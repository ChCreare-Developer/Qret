<?php
	echo "<title>馬上就好</title>";
	echo "<center><h1>歡迎使用Qret頁面自定義工具！</h1></center>";
	echo "<center><p>Version=Beta01</p></center>";
	echo "<center><p>當你看到這個界面時，你的Qret和伺服器的PHP已經準備就緒</p></center>";
	echo "<center><p>請<a href=config.html>點這裡</a>繼續</p></center>";
?>