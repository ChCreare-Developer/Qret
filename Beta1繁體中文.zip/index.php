<?php
	$fe=fopen("Dirs.txt","r") or die("Error:Not's Read Config Files");
	$dirs=fread($fe,filesize('Dirs.txt'));
	fclose($fe);
	$caption=file_get_contents("$dirs/caption.txt");
	$title=file_get_contents("$dirs/title.txt");
	$text=file_get_contents("$dirs/text.txt");
	$type=file_get_contents("$dirs/type.txt");
	switch ($type)
	{
		case "Basic":
			echo("<title>$title</title>");
			echo("<h1>$caption</h1>");
			echo("<p>$text</p>");
			break;
		case "Basic-Center":
			echo("<title>$title</title>");
			echo("<center><h1>$caption</h1></center>");
			echo("<center><p>$text</p></center>");
			break;
		default:
			echo("<title>$title</title>");
			echo("<h1>$caption</h1>");
			echo("<p>$text</p>");
			echo('<script>alert("這個網站出現了範本問題，您看到的介面是預設範本")</script>');	
	}
?>