<?php
	if(file_exists("Dirs.txt"))
	{
		$fe=fopen("Dirs.txt","r");
		$dirs=fread($fe,filesize('Dirs.txt'));
		fclose($fe);
	}
	else
	{
		Error2("Dirs.txt");
	}
	if(!is_dir("$dirs"))
	{
		Error2("$dirs/");
	}
	if(!file_exists("$dirs/caption.txt"))
	{
		Error2("$dirs/caption.txt");
	}
	elseif(!file_exists("$dirs/title.txt"))
	{
		Error2("$dirs/title.txt");
	}
	elseif(!file_exists("$dirs/text.txt"))
	{
		Error2("$dirs/text.txt");
	}
	elseif(!file_exists("$dirs/type.txt"))
	{
		Error2("$dirs/type.txt");
	}
	else
	{
		$caption=file_get_contents("$dirs/caption.txt");
		$title=file_get_contents("$dirs/title.txt");
		$text=file_get_contents("$dirs/text.txt");
		$type=file_get_contents("$dirs/type.txt");
	}
	switch ($type)
	{
		case "Basic":
			echo("<title>$title</title>");
			echo("<h1>$caption</h1>");
			echo("<p>$text</p>");
			break;
		case "Basic-Center":
			echo("<title>$title</title>");
			echo("<center><h1>$caption</h1></center>");
			echo("<center><p>$text</p></center>");
			break;
		default:
			echo "<title>Error Page</title>";
			echo "<h1>出現了一個錯誤</h1>";
			echo "<hr>";
			echo "<p>您的主題檔出現了錯誤，請更改主題檔後重試</p>";
			exit();
	}
	function Error2($filename)
	{
		echo "<title>Error Page</title>";
		echo "<h1>出現了一個錯誤</h1>";
		echo "<hr>";
		echo "<p>您的設定檔出現了錯誤，請<a href=config.html>重新配置</a>後重試</p>";
		echo "<p>錯誤點:$filename</p>";
		exit();
	}
?>